var http = require('http');
const https = require('https');
//var logTap=require("./loggerTap.js");
var RecordingTap=require("./RecordingTap.js");
var ConsoleTap=require("./consoleTap.js");
var ProxyTap=require("./ProxyTap.js");

function createTaps(){
  var tapRunner=new ProxyTap();
//  tapRunner.addTap(new ConsoleTap());
  tapRunner.addTap(new RecordingTap());
  return tapRunner;
}
function getOptions(request,defaultPort){
  var rawHost=request.headers['host'];
  var strs=rawHost.split(":");
  var destHost=strs[0];
  var destPort=strs[1] || defaultPort;
  var options={
        hostname: destHost,
        port:destPort,
        path:request.url,//request.path,//
        method:request.method,
        headers: request.headers,
        rejectUnauthorized: false,
      };
  return options;
}
function isHttpsChannel(req){
  return req.connection.encrypted || false;
}
function isHttps(req){
  return req.url.startsWith("https")
}
exports.run=function(request, response) {
  var proxyTap=createTaps();
  var client=http;
  var defaultPort=80;
  if(isHttpsChannel(request)){
    client=https;
    defaultPort=443;
  }
  var options=getOptions(request,defaultPort);
//  console.log("Proxy Recording Service: req options:%s",JSON.stringify(options));
  proxyTap.onRequest(request,options);

  var proxy_request= client.request(options, (res) => {
      proxyTap.onResponse(res);
    //  res.setEncoding('utf8');
      res.on('data', (chunk) => {
        proxyTap.onData(chunk);
        response.write(chunk, 'binary');
      });
      res.on('end', () => {
        proxyTap.onEnd();
        response.end();
        });
     });
    request.addListener('data', function(chunk) {
      proxy_request.write(chunk, 'binary');
    });
    request.addListener('end', function() {
      proxy_request.end();
    });
}
exports.serviceName=function(){
  return "Proxy Recording Service";
}
