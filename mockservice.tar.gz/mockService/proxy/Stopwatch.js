
function Stopwatch(){
  this.startTime=Date.now();
};
Stopwatch.prototype={
  start:function(){
    this.startTime=Date.now();
  },
  stop:function(){
    if(this.startTime==null)
      return -1;
    this.stopTime=Date.now();
    this.expense=this.stopTime-this.startTime;
    return this.expense;
  }
}
module.exports=Stopwatch;

// function test(){
//   var watch=new Stopwatch();
//   watch.start();
//   setTimeout(function(){
//     var expense=watch.stop();
//     console.log("time elapse %d", expense);
//   },100)
//
// }
// test();
