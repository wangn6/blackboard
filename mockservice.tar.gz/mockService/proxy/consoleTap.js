
function ConsoleTap(name){
  this.name=name;
  this.chunkCounter=1;
}
ConsoleTap.prototype={
  onResponse:function(res){
    console.log(`STATUS: ${res.statusCode}`);
    console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
  },
  onRequest:function(request,options){
       console.log("new request old counter=%d",this.chunkCounter);
       chunkCounter=1;
       console.log("options:",options);
       console.log(`new request: ${request.method} ${request.headers['host']} ${request.url}`)
    },
  onData:function(chunk){
         console.log("chunk %d",this.chunkCounter++)
      },
  onEnd:function(){
      console.log("chunk done.")
  }
}
// exports.onResponse=function(res){
//   console.log(`STATUS: ${res.statusCode}`);
//   console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
// }
// exports.onRequest=function(request,options){
//      console.log("new request old counter=%d",chunkCounter);
//      chunkCounter=1;
//      console.log("options:",options);
//      console.log(`new request: ${request.method} ${request.headers['host']} ${request.url}`)
//   }
// exports.onData=function(chunk){
//      console.log("chunk %d",chunkCounter++)
//   }
// exports.onEnd=function(){
//      console.log("chunk done.")
//   }
module.exports=ConsoleTap;
