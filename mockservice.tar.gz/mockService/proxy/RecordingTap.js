var memStore=require("../memStore.js");
var Stopwatch=require("./Stopwatch.js");
function RecordingTap(store){
  this.watch=new Stopwatch();
  this.store=store || memStore
}
RecordingTap.prototype={
  onRequest:function(request,options){
       this.watch.start();
       this.req=options;
       this.options=options;
    },
  onResponse:function(res){
    this.res={};
    this.res.status=res.statusCode;
    this.res.headers=res.headers;
    this.res.body='';
  },
  onData:function(chunk){
     this.res.body+=chunk;
  },
  onEnd:function(){
    this.res.elapse=this.watch.stop();
    this.store.put(this.req,this.res);
  }
}
module.exports=RecordingTap;
