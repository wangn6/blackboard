var http = require('http');
const https = require('https');
//var logTap=require("./loggerTap.js");
var RecordingTap=require("./RecordingTap.js");
var ConsoleTap=require("./consoleTap.js");
var ProxyTap=require("./ProxyTap.js");

function getOptions(request,defaultPort){
  var rawHost=request.headers['host'];
  var strs=rawHost.split(":");
  var destHost=strs[0];
  var destPort=strs[1] || defaultPort;
  var options={
        hostname: destHost,
        port:destPort,
        path:request.url,//request.path,//
        method:request.method,
        headers: request.headers,
        rejectUnauthorized: false,
      };
  return options;
}
function isHttpsChannel(req){
  return req.connection.encrypted || false;
}

exports.start=function(store){
  return function(request, response) {
    var proxyTap=new ProxyTap();
    proxyTap.addTap(new RecordingTap(store)); // each request should use a seperate record tap
    var client=http;
    var defaultPort=80;
    if(isHttpsChannel(request)){
      client=https;
      defaultPort=443;
    }
    var options=getOptions(request,defaultPort);
    proxyTap.onRequest(request,options);
    var proxy_request= client.request(options, (res) => {
        proxyTap.onResponse(res);
        response.writeHead(res.statusCode,res.headers);
        res.on('data', (chunk) => {
          proxyTap.onData(chunk);
          response.write(chunk, 'binary');
        });
        res.on('end', () => {
          proxyTap.onEnd();
          response.end();
          });
       });
      request.addListener('data', function(chunk) {
        proxy_request.write(chunk, 'binary');
      });
      request.addListener('end', function() {
        proxy_request.end();
      });
    proxy_request.on('error',function(e){
      response.writeHead(500);
      response.write('Proxy Server Access Remote Server Error:'+e);
      response.end();
    })
  }
}

exports.serviceName=function(){
  return "Proxy Recording Service";
}
