var fs=require('fs');
var memStore=require("./memStore.js");
var Stopwatch=require("./Stopwatch.js");
//var fileWriter;
//var fileWriter=fs.createWriteStream("log.json");
function LoggerTap(){
  this.data={};
  this.watch=new Stopwatch();
}
var data={};
var watch=new Stopwatch();
exports.onRequest=function(request,options){
//     var fileWriter=fs.createWriteStream("log.json");
    // data={req:options,status:'',res:{headers:'',body:''}};
     watch.start();
     data.req=options;
     //console.log(`new request: ${request.method} ${request.headers['host']} ${request.url}`)
  }
exports.onResponse=function(res){
    // console.log(`STATUS: ${res.statusCode}`);
    // console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
    //fileWriter.write(JSON.stringify(res));
    data.res={};
    data.res.status=res.statusCode;
    data.res.headers=res.headers;
    data.res.body='';
  }
exports.onData=function(chunk){
     data.res.body+=chunk;
  }
exports.onEnd=function(){
  var expense=watch.stop();
  memStore.put("test",data.req,data.res);
  fs.writeFile('log.json',JSON.stringify(data),  (err) => {
    if (err) throw err;
      console.log('The file has been saved!');
    });
  }
