
var ObjectStore=require("../db/ObjectStore.js");
var FileDb=require("../db/FileDb.js");
var MockServer=require("../MockServer.js");
function MockServerStore(dbpath){
  this.store=new ObjectStore(new FileDb(dbpath));
}
MockServerStore.prototype.get=function(hostname,version,onComplete){
  this.store.get(hostname,version,function(err,data){
    if(err){
      onComplete(err)
    }else{
      onComplete(null,new MockServer(hostname,data.version,data.data))
    }
  })
}
MockServerStore.prototype.list=function(onComplete){
  this.store.list(function(err,map){
    if(err){
      onComplete(err)
    }else{
      onComplete(null,map)
    }
  })
}
MockServerStore.prototype.save=function(mockServer,onComplete){
  this.store.put(mockServer.getName(),mockServer.getVersion(),mockServer.getData(),null,onComplete)
}
MockServerStore.prototype.clear=function(onComplete){
  this.store.clear(onComplete)
}
module.exports=MockServerStore
