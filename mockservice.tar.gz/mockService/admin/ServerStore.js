var fs=require('fs');
var MockServer=require("../MockServer.js");
var MockServerStore=require("../admin/MockServerStore.js");

function Store(path){
  this.path=path;
  if(!fs.existsSync(path))
    fs.mkdirSync(path);
  this.mockServerStore=new MockServerStore(path);
}
Store.prototype.prepare=function(arr,onComplete){
  var async=require('async');
  var self=this;
  function addServer(elm,callback){
    self.mockServerStore.save(new MockServer(elm.key,elm.version,elm.data),function(err){ callback(err)})
  }
  async.eachSeries(arr,addServer,onComplete)
}
Store.prototype.getStore=function(){
  return this.mockServerStore;
}
Store.prototype.clear=function(onComplete){
  var self=this;
  this.mockServerStore.clear(function(err){
    console.log("clear mockServerStore :",err);
    fs.rmdir(self.path,onComplete);
  })
}
module.exports=Store
