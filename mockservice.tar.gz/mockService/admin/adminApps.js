var ControlPanel=require("./ControlPanel.js");
var MockServerStore=require("./MockServerStore.js");
var Apps=require("../blankServer/Apps3.js");
var DB_PATH='./data';


function error(response,err){
  var status=400;
  response.writeHead(status);
  response.end(err);
}
function success(response,data){
  var str=typeof data==='string'?data:JSON.stringify(data);
  response.end(str);
}
function getApps(mockServerStore){
  this.controlPanel=new ControlPanel(mockServerStore);
  this.apps=new Apps();
}
/**
200:
  [{hostname:"www.example.com:8080",run:{version:"",startedTime:"",service:"RECORD | MOCK"},versions:["v1","v2"]}]
**/
apps.get("/servers",function(request, response){
  controlPanel.listServers(function(err,data){
    if(err){
      error(response,err);
    }else{
      success(response,data);
    }
  })
});
/**  start a mockServer
PUT  /routes
{name:"",version:""}
200 {name:"",version:"",started:"",stopped:""}  // same server with different version is running
404 "NOT EXIST"
**/
apps.put("/routes",function(request,response){
  // start a mockServer
  var serverInfo=JSON.parse(request.body);
  controlPanel.startServer(serverInfo.name,serverInfo.version,function(err,mockServer){
    if(err){
      error(response,err);
    }else{
      success(response,mockServer.info());
    }
  })
});
/**  stop a mockServer
DELETE  /routes
{hostname:""}
200 {hostname:""}  // same server with different version is running
201 {hostname:"",version:"",startedTime:""}  //
404 "NOT EXIST"
**/
apps.del("/routes/{servername}",function(request, response){
  // stop a mockServer
  controlPanel.stopServer(request.params.servername,function(err,mockServer){
    if(err){
      error(response,err);
    }else{
      success(response,mockServer.info());
    }
  })
});
exports.prototype.apps=apps;
