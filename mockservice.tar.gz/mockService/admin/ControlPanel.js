var route=require("../route.js");
function ControlPanel(store){
  this.store=store;
}
/***
// onComplete(err,mockServer)
err:"ERR_SERVER_ALREADY_RUNNING" ,"ERR_SERVER_NOT_EXIST"
***/
ControlPanel.prototype.startServer=function(hostname,version,onComplete){
  function isRunning(server){
    return server && version===server.getVersion();
  }
  if(!hostname ){
    throw new Error("hostname must specified")
  }
  var server=route.get(hostname);
  if(isRunning(server)){
    onComplete(null,server);
  }else{
    this.store.get(hostname,version,function(err,mockServer){
      if(mockServer){
        if(route.add(mockServer)){
          onComplete(null,mockServer);
        }else{
          onComplete("ERR_SERVER_ALREADY_RUNNING")
        }
      }else{
    //    console.log("controlPanel startServer err:%s",JSON.stringify(err))
        onComplete("ERR_SERVER_NOT_EXIST");
      }
    })
  }
}

ControlPanel.prototype.stopServer=function(hostname,onComplete){
  var mockServer=route.remove(hostname)
  if(mockServer){
    if(mockServer.isRecording()){
      this.store.save(mockServer,function(err){onComplete(err,mockServer)});
    }else{
      onComplete(null,mockServer)
    }
  }else{
    onComplete("ERR_SERVER_NOT_RUNNING")
  }
}
/***
onComplete({
  recordings:[{name:"",version:'',startedTime:''}],
  mockings:[{name:"",version:'',startedTime:''}]
  archived:[{name:"",versions:['v1','v2']}]
})
***/
ControlPanel.prototype.listServers=function(onComplete){
  // merge severs from route and db
  function toVersionInfo(key,map){
    var versions=map[key];
    var result=versions.map(function(elm){
      return elm.version;
    })
    return {name:key,versions:result}
  }
  function flatMap(map,flat){
    var keys=Object.keys(map);
    var result=[];
    keys.forEach(function(key){
      result.push(flat(key,map))
    })
    return result;
  }
  function groupRunnings(){
    var map=route.list();
    var keys=Object.keys(map);
    var recordings=[];
    var mockings=[];
    keys.forEach(function(key){
      var server=map[key];
      if(server.isRecording()){
        recordings.push(server.info())
      }else{
        mockings.push(server.info())
      }
    })
    return {recordings:recordings,mockings:mockings};
  }
  var actives=groupRunnings();
  this.store.list(function(err,data){
    // ignore err
    var dt=data || {}
//    console.log("list archived:%s:",JSON.stringify(dt))
    onComplete(err,{recordings:actives.recordings,mockings:actives.mockings,archived:flatMap(dt,toVersionInfo)})
  })
}
/***
onComplete({
  running:[{name:"",version:''}],
  archived:[{name:"",versions:['v1','v2']}]
})
***/
ControlPanel.prototype.listServersOld=function(onComplete){
  // merge severs from route and db
  function toVersionInfo(key,map){
    var versions=map[key];
    var result=versions.map(function(elm){
      return elm.version;
    })
    return {name:key,status:'archived',versions:result}
  }
  function flatMap(map,flat){
    var keys=Object.keys(map);
    var result=[];
    keys.forEach(function(key){
      result.push(flat(key,map))
    })
    return result;
  }
  function flatServer(key,map){
    var server=map[key];
  //  return {name:key,version:server.getVersion()}
    return server.info();
  }
  var actives=flatMap(route.list(),flatServer);
  this.store.list(function(err,data){
    // ignore err
    var dt=data || {}
//    console.log("list archived:%s:",JSON.stringify(dt))
    onComplete(err,{running:actives,archived:flatMap(dt,toVersionInfo)})
  })
}
module.exports=ControlPanel
