var BlankServer=require("../blankServer/BlankServer.js");
var ControlPanel=require("./ControlPanel.js");
var Apps=require("../blankServer/Apps3.js");


function error(response,err){
  var status=400;
  response.writeHead(status);
  response.end(err);
}
function success(response,data){
  var str=typeof data==='string'?data:JSON.stringify(data);
  response.setHeader('Content-Type', 'application/json');
  response.setHeader('Access-Control-Allow-Origin','*');
  response.setHeader('Access-Control-Allow-Methods','POST, GET, OPTIONS,DELETE,PUT');
  response.end(str);
}

function initApps(apps,store){
  var controlPanel=new ControlPanel(store);
  /**
  200:
  {
    running:[{name:"",version:''}],
    archived:[{name:"",versions:['v1','v2']}]
  }
  **/
  apps.get("/servers",function(request, response){
    controlPanel.listServers(function(err,data){
      if(err){
        error(response,err);
      }else{
        success(response,data);
      }
    })
  });
  /**  start a mockServer
  PUT  /routes
  {name:"",version:""}
  200 {name:"",version:"",started:"",stopped:""}  // same server with different version is running
  404 "NOT EXIST"
  **/
  apps.put("/routes",function(request,response){
    // start a mockServer
    var serverInfo=JSON.parse(request.body);
    controlPanel.startServer(serverInfo.name,serverInfo.version,function(err,mockServer){
      if(err){
        error(response,err);
      }else{
        success(response,mockServer.info());
      }
    })
  });
  /**  stop a mockServer
  DELETE  /routes
  {hostname:""}
  200 {hostname:""}  // same server with different version is running
  201 {hostname:"",version:"",startedTime:""}  //
  404 "NOT EXIST"
  **/
  apps.del("/routes/{servername}",function(request, response){
    // stop a mockServer
    controlPanel.stopServer(request.params.servername,function(err,mockServer){
      if(err){
        error(response,err);
      }else{
        success(response,mockServer.info());
      }
    })
  });
}
exports.start=function(port,store,staticOptions){
  var adminPort=port || 8081;
  var apps=new Apps();
  initApps(apps,store);
  var adminServer=new BlankServer("Admin Server",apps,null,staticOptions);
  adminServer.startHttp(adminPort);
  //return adminServer;
}
