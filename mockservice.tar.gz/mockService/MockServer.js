var mockService=require("./mock/mockService2.js");
var proxyService=require("./proxy/proxyService2.js");
var MemCache=require("./MemCache.js");

function dateToVersion(dt){
  function pad(number) {
      if (number < 10) {
        return '0' + number;
      }
      return number;
    }
  return dt.getFullYear() +
        '-' + pad(dt.getMonth() + 1) +
        '-' + pad(dt.getDate()) +
        'T' + pad(dt.getHours()) +
        ':' + pad(dt.getMinutes()) +
        ':' + pad(dt.getSeconds());
}
function MockServer(name,version,data){
  this.name=name;
  this.cache=new MemCache(data);
  this.version= typeof version==='string'?version:dateToVersion(version);
  if(data){
    this.service=mockService.start(this.cache,0);
    this.serviceName=mockService.serviceName();
  }else{
    this.service=proxyService.start(this.cache);
    this.serviceName=proxyService.serviceName();
  }
}
MockServer.prototype.getName=function(){
  return this.name;
}
MockServer.prototype.getVersion=function(){
  return this.version;
}
MockServer.prototype.isRecording=function(){
  return this.serviceName===proxyService.serviceName()
}

MockServer.prototype.isMocking=function(){
  return this.serviceName===mockService.serviceName()
}
MockServer.prototype.run=function(request,response){
  this.service(request,response)
}
MockServer.prototype.start=function(){
  this.startedTime=new Date();
}
MockServer.prototype.stop=function(){
  this.stoppedTime=new Date();
}
MockServer.prototype.getData=function(){
  return this.cache.getAll();
}
MockServer.prototype.info=function(){
  return {name:this.name,version:this.version,startedTime:this.startedTime,stoppedTimed:this.stoppedTime};
}

module.exports=MockServer;
