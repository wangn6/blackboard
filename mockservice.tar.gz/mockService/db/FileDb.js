var fs=require('fs');
var path=require('path');
function FileDb(path){
  this.path=path;
  if(!fs.existsSync(this.path))
    throw new Error(path+" NOT exists!");
}
function getFullPath(dbdir,key){
  return path.join(dbdir,key);
}
FileDb.prototype.put=function(key,data,onComplete){
  var str= typeof data ==='string'? data:JSON.stringify(data);
  fs.writeFile(getFullPath(this.path,key),str,onComplete);
}
FileDb.prototype.del=function(key,onComplete){
  var filename=getFullPath(this.path,key);
  fs.unlink(filename,function(err){
    if(err && err.code==='ENOENT'){
        console.log("file not exist:%s",filename)
        onComplete(null)
    }else
       onComplete(err)
  });
}
FileDb.prototype.get=function(key,onComplete){
  var self=this;
  var fileName=getFullPath(this.path,key);
  fs.readFile(fileName,'utf8',onComplete);
}
module.exports=FileDb
