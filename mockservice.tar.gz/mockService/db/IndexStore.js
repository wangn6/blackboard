/**======index.json====
{
  key:[{version:"timestamp",data:{}},{version:"timestamp",url:"host1-date2.json"}],
}

***/
function IndexStore(db,idxFileName){
  this.db=db;
  this.indexFileName=idxFileName || "index.json";
  this.idxMap=null;
}

IndexStore.prototype.list=function(onComplete){
  var self=this;
  if(this.idxMap){
//    console.log("current idx map:%s",JSON.stringify(this.idxMap));
    onComplete(null,this.idxMap)
  }else{
    this.db.get(this.indexFileName,function(err,data){
      var error=null;
      if(err){
        if(err.code==='ENOENT'){ // index file not existing
          self.idxMap= {};
        }else{
          console.error('open index error:%s',JSON.stringify(err));
          error=err;
        }
      }else{
        self.idxMap=JSON.parse(data) || {};
      }
  //    console.log("load idx map:%s",JSON.stringify(self.idxMap));
      onComplete(error,self.idxMap);
    })
  }
}
IndexStore.prototype.put=function(key,version,url,data,onComplete){
  var self=this;
  function addToMap(map){
    var versions=map[key];
    if(!versions){
      versions=[];
      map[key]=versions;
    }
    if(!data || Object.keys(data).length===0){
      versions.push({version:version,url:url})
    }else{
      versions.push({version:version,url:url,data:data});
    }
  }
  this.list(function(err,idxMap){
    if(err){
      onComplete(err)
    }else{
      addToMap(idxMap) // update memory
  //    console.log("IndexMap After Add:%s",JSON.stringify(idxMap))
      self.db.put(self.indexFileName,idxMap,onComplete)  // update file
    }
  })
}

IndexStore.prototype.del=function(key,version,onComplete){
  var self=this;
  function delFromMap(map){
    var versions=map[key];
    var vers=versions;
    if(versions){
      vers=versions.filter(function(elm){
        return elm.version!=version;
      })
      map[key]=vers;
    }
  }
  this.list(function(err,idxMap){
    if(err){
      onComplete(err)
    }else{
      delFromMap(idxMap) // update memory
      self.db.put(self.indexFileName,idxMap,onComplete)  // update file
    }
  })
}
// onComplete(err,idx)
// idx:{version:"",data:{}}
function getVersionData(versions,version){
  if(version){
    var result=versions.find(function(elm){
      return version===elm.version;
    })
  }else{
    result=versions[versions.length-1] // latest version
  }
  return result
}
IndexStore.prototype.get=function(key,version,onComplete){
  var self=this;
  this.list(function(err,idxMap){
    var dataArr=idxMap[key];
    if(dataArr){
      var result=getVersionData(dataArr,version)
      var err=result ? null:version+" not found in "+key ;
    }else{
      err=key+" not found";
    }
    onComplete(err,result);
  })
}
IndexStore.prototype.clear=function(onComplete){
  var self=this;
  self.db.del(self.indexFileName,function(err){
    self.idxMap=null;
    onComplete(err);
  })
}
module.exports=IndexStore;
