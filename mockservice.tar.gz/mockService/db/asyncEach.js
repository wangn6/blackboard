function asyncEach(arrOrObj,func,callback){
  if(typeof func!='function'){
    throw new Error("asyncEach's second param must be function")
  }
  var keys=Object.keys(arrOrObj);
  var results={};
  var errors={};
  var leftCount=keys.length;
  function isEmpty(obj){
    return Object.keys(obj).length===0
  }
  function mycallback(key){
    return function(err,result){
      leftCount--;
      if(err){
        errors[key]=err;
      }else{
        results[key]=result;
      }
      if(leftCount===0){
        if(isEmpty(errors)){
          callback(null,results);
        }else {
          callback(errors,results);
        }
      }
    }
  }
  if(leftCount>0){
    keys.forEach(function(key){
      func(arrOrObj[key],mycallback(key));
    })
  }else{
    callback(null,results)
  }
}
exports.each=asyncEach
