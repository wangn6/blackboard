var IndexStore=require('./IndexStore.js');
var asyncEach=require('../db/asyncEach.js').each;
/*** Object store structure
  /--
   index.json
   key-version.json
   host1-date2.json
   host2-date1.json

}
***/
function createUrl(key,version,metaData){
  return key+"-"+version;
}
function ObjectStore(db,toUrl){
  this.db=db;
  this.indexDb=new IndexStore(db);
  this.toUrl=toUrl || createUrl;
}

ObjectStore.prototype.put=function(key,version,data,metaData,onComplete){
  var self=this;
  var url=this.toUrl(key,version,metaData);
  this.db.put(url,data,function(err){
    if(err){
      onComplete(err)
    }else{
      self.indexDb.put(key,version,url,metaData,onComplete)
    }
  })
}
ObjectStore.prototype.del=function(key,version,onComplete){
  var self=this;
  this.indexDb.get(key,version,function(err,idx){
    if(err){
      onComplete(err)
    }else{
      self.db.del(idx.url,function(err){
        if(err){
          onComplete(err)
        }else{
          self.indexDb.del(key,version,onComplete);
        }
      })
    }
  });
}
//onComplete(err,serverList)
ObjectStore.prototype.list=function(onComplete){
  this.indexDb.list(onComplete);
}
// serverName: "www.example.com:8081"
// key: "20170616-130530"
// onComplete(err,{version:'',data:{}})
ObjectStore.prototype.get=function(key,version,onComplete){
  var self=this;
  this.indexDb.get(key,version,function(err,idx){
    if(err){
      onComplete(err)
    }else{
      self.db.get(idx.url,function(err,data){onComplete(err,{version:idx.version,data:JSON.parse(data)})})
    }
  });
}
// clear all data and index
ObjectStore.prototype.clear=function(onComplete){
  var self=this;
  function getAllUrl(map){
    var urls=[];
    var keys=Object.keys(map);
    keys.forEach(function(key){
      var versions=map[key];
      if(versions){
        versions.forEach(function(idx){
          urls.push(idx.url);
        })
      }
    })
    return urls;
  }
  function delAll(map,onAllDeleted){
    var urls=getAllUrl(map);
    function delData(url,callback){
      self.db.del(url,function(err){
        callback(err,url)
      })
    }
    asyncEach(urls,delData,onAllDeleted);
  }
  function delIndex(){
    self.indexDb.clear(onComplete);
  }
  self.indexDb.list(function(err,idxMap){
    if(err){
      onComplete(err)
    }else{
      delAll(idxMap,function(err,results){
          if(err){
            onComplete(err);
          }else{
//              delIndex()
          }
      })
    }
  });
  delIndex()
}
module.exports=ObjectStore
