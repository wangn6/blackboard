var http = require('http');
var url = require('url');

var store=require("./memStore.js");
var Apps=require("./blankServer/apps2.js");
var BlankServer=require("./blankServer/BlankServer.js");
var services=require("./services.js");
var apps=new Apps();
function app(pathName,app){
  apps.get(pathName,app);
}
app("/record",function(request, response){
  services.record();
  response.end('recording is running.');
});
app("/mock",function(request, response){
  services.mock();
  response.end('mocking is running.');
});
app("/status",function(request, response){
  var status=services.isMocking()?"mocking":"recording";
  response.end(status);
});
app("/save",function(request, response){
  store.log(function(msg){
    response.end(msg);
  })
});
app("/cache",function(request, response){
  response.end(JSON.stringify(store.getAll()));
});

exports.start=function(port){
  var adminPort=port || 8081;
  var adminServer=new BlankServer("Admin Server",apps);
  adminServer.startHttp(adminPort);
  //return adminServer;
}
