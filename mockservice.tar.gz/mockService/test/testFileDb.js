var fs=require('fs');
var should=require('should');
var FileDb=require("../db/FileDb.js")

var db
function test(fileName,data,done){
  db.put(fileName,data,function(err){
      should(err).null();
      db.get(fileName,function(error,jsonData){
        should(error).null();
        should(typeof jsonData).equal('object');
        db.del(fileName,done)
      })
  })
}
describe('Test FileFb', function() {
  var DB_PATH='./tmp';
  before(function() {
    if(!fs.existsSync(DB_PATH))
      fs.mkdirSync(DB_PATH)
    db=new FileDb(DB_PATH);
  });
  after(function(){
    fs.rmdirSync(DB_PATH)
  });
  var fileName="test.json";
  var data={name:"test",age:19};
  it('put a json to db', function(done) {
    test(fileName,data,done)
  });
  it('put string to db', function(done) {
    test(fileName,JSON.stringify(data),done)
  });
  it('overwite existing data',function(done) {
    db.put(fileName,data,function(err){
      test(fileName,JSON.stringify(data),done)
    });
  });
  it('filename with prefix /', function(done) {
    test("/"+fileName,JSON.stringify(data),done)
  });
  it('del non exist file', function(done) {
    db.del("not-exist.txt",done)
  });
});
