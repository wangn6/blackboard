var httpClient=require('./httpClient.js');

function AdminClient(port,hostname){
  this.hostname=hostname || "localhost";
  this.port=port || 8081
}
AdminClient.prototype.doRequest=function(path,callback){
  var options = {
    host: this.hostname,
    port: this.port,
    path: path,
  };
  httpClient.request(options,callback);
}
AdminClient.prototype.mock=function(onComplete){
 this.doRequest("/mock",onComplete)
}
AdminClient.prototype.record=function(onComplete){
  this.doRequest("/record",onComplete)
}
AdminClient.prototype.status=function(onComplete){
  this.doRequest("/status",onComplete)
}
module.exports=AdminClient
