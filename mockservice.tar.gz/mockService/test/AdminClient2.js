var HttpClient=require('./HttpClient2.js');

function AdminClient(port,hostname){
  this.client=new HttpClient(hostname ||'localhost',port)
}
AdminClient.prototype.listServer=function(callback){
  this.client.get('/servers',null,callback);
}
AdminClient.prototype.stopServer=function(name,onComplete){
 this.client.del("/routes/"+name,null,onComplete)
}
AdminClient.prototype.startServer=function(name,version,onComplete){
 this.client.put("/routes",null,{name:name,version:version},onComplete)
}
module.exports=AdminClient
