var should=require('should');
var AdminClient=require("./adminClient.js");
var adminServer=require("../adminServer.js");
function assertResponse(result,status,body){
//  console.log("status:%d body:%s",result.statusCode,result.body);
  result.statusCode.should.equal(status);
  result.body.should.equal(body);
}
describe('Test Admin Console', function() {
  var port=18081;
  before(function() {
    adminServer.start(port,function(){
      console.log("server is ready on %d",port)
    })
  });
  // after(function() {
  //   // runs after all tests in this block
  // //  myServer.close();
  //   console.log("server is closed",port)
  // });
  var client=new AdminClient(port);
  it('server should started in recording mode', function(done) {
    client.status(function(err,res){
        should(err).null();
        assertResponse(res,200,"recording");
        done()
    })
  });
  it('swith to mocking mode', function(done) {
    client.mock(function(err,res){
        should(err).null();
        assertResponse(res,200,"mocking is running.")
        done()
    })
  });
  it('after swithc to mocking mode,status should be mocking', function(done) {
    client.status(function(err,res){
        should(err).null();
        assertResponse(res,200,"mocking")
        done()
    })
  });
  it('swithback to recording mode', function(done) {
    client.record(function(err,res){
        should(err).null();
        assertResponse(res,200,"recording is running.")
        done()
    })
  });
});
