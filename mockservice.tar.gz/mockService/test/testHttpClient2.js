var should=require('should');
var HttpClient=require("./HttpClient2.js");
var proxyServer=require("../proxyServer2.js");
const EchoServer=require("../blankServer/EchoServer.js");
describe('Test HttpClient', function() {
  var rrList=[{req:{path:"/testget"},res:{statusCode:200,body:"get hello/a/1"}},
        {req:{method:"POST",path:"/testpost"},res:{statusCode:200,body:"testpost"}},
        {req:{method:"PUT",path:"/testput"},res:{statusCode:200,body:"testput"}},
        {req:{method:"DELETE",path:"/testdel"},res:{statusCode:200,body:"testdel"}},
      ];
  var rrSecureList=[{req:{path:"/testget"},res:{statusCode:200,body:"secureget"}},
        {req:{method:"POST",path:"/testpost"},res:{statusCode:200,body:"securepost"}},
        {req:{method:"PUT",path:"/testput"},res:{statusCode:200,body:"secureput"}},
        {req:{method:"DELETE",path:"/testdel"},res:{statusCode:200,body:"securedel"}},
      ];
  var testServer=new EchoServer("Test Server");
  var client=new HttpClient('localhost',8082);
  var secureClient=new HttpClient('localhost',8443,true);
  var proxyClient=new HttpClient('localhost',8082,false,'localhost','8080');
  function assertSuccess(expected,done){
    return function(err,res){
        should(err).null();
        res.statusCode.should.equal(expected.statusCode);
        res.body.should.equal(expected.body);
        done()
    }
  }
  before(function() {
    testServer.prepare(rrList,rrSecureList);
    testServer.start(8082,8443);
    proxyServer.start();
  });
  it('get success', function(done) {
    client.get("/testget",null,assertSuccess({statusCode:200,body:"get hello/a/1"},done))
  });
  it('put success', function(done) {
    client.put("/testput",null,"myputdata",assertSuccess({statusCode:200,body:"testputmyputdata"},done))
  });
  it('post success', function(done) {
    client.post("/testpost",null,"mypostdata",assertSuccess({statusCode:200,body:"testpostmypostdata"},done))
  });
  it('delete success', function(done) {
    client.del("/testdel",null,assertSuccess({statusCode:200,body:"testdel"},done))
  });
  it('secure get success', function(done) {
    secureClient.get("/testget",null,assertSuccess({statusCode:200,body:"secureget"},done))
  });
  it('secure put success', function(done) {
    secureClient.put("/testput",null,"myputdata",assertSuccess({statusCode:200,body:"secureputmyputdata"},done))
  });
  it('secure post success', function(done) {
    secureClient.post("/testpost",null,"mypostdata",assertSuccess({statusCode:200,body:"securepostmypostdata"},done))
  });
  it('secure delete success', function(done) {
    secureClient.del("/testdel",null,assertSuccess({statusCode:200,body:"securedel"},done))
  });
  it('proxy get success', function(done) {
    proxyClient.get("/testget",null,assertSuccess({statusCode:200,body:"get hello/a/1"},done))
  });
  it('proxy put success', function(done) {
    proxyClient.put("/testput",null,"myputdata",assertSuccess({statusCode:200,body:"testputmyputdata"},done))
  });
  it('proxy post success', function(done) {
    proxyClient.post("/testpost",null,"mypostdata",assertSuccess({statusCode:200,body:"testpostmypostdata"},done))
  });
  it('proxy delete success', function(done) {
    proxyClient.del("/testdel",null,assertSuccess({statusCode:200,body:"testdel"},done))
  });
});
