var should=require('should');
var assertObj=require('./assertObj.js').assertObj;
var ParamStr=require('../blankServer/ParamStr.js');
function test(paramStr,matchStr,expected){
  var paramStr=new ParamStr(paramStr);
  var result=paramStr.match(matchStr);
  console.log("result:%s",JSON.stringify(result))
  if(typeof expected ==='object')
    assertObj(result,expected);
  else {
    should(result).equal(expected)
  }
}
describe('Test ParamString', function() {
  describe('match param String', function() {
    it(" with two params", function() {
      test('/path/to/{a123}/and/{bB}','/path/to/12-3/and/ab',{a123:'12-3',bB:'ab'})
    });
    it(" with less params", function() {
      test('/path/to/{a123}/and/{bB}','/path/to/123/and/',false)
    });
    it(" with more params", function() {
      test('/path/to/{a123}/and/{bB}','/path/to/123/and/1/2',false)
    });
    it(" with mismatched str", function() {
      test('/path/to/{a123}/and/{bB}','/path/To/123/and/1/2',false)
    });
    it("path with special chars:'- . :'", function() {
      test('/routes/{servername}','/routes/mlcs-stage-vir.mobile.medu.com',{servername:'mlcs-stage-vir.mobile.medu.com'})
    });
  });
  describe('non param String', function() {
    it("non param string matched is true", function() {
      test('/path/to/data','/path/to/data',true)
    });
    it("non param string not matched is false", function() {
      test('/path/to/data','/path/to/data1',false)
    });
  });
});
