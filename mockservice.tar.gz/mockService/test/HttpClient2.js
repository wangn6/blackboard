var http=require('http');
var https=require('https');
var HttpsProxyAgent = require('https-proxy-agent');
function HttpClient(host,port,isSecure,proxyHost,proxyPort){
  this.host=host || localhost;
  this.port=port ;
  this.proxyHost=proxyHost;
  this.proxyPort=proxyPort;
  this.isSecure=isSecure;
}
HttpClient.prototype.doRequest=function(method,path,headers,data,callback){
  var options={
    method:method,
    path:path,
    headers:headers || {},
    host:this.host,
    port:this.port,
    rejectUnauthorized:false
  }
  if(this.proxyHost){
    if(this.isSecure){
      var proxy = 'http://'+this.proxyHost+':'+this.proxyPort;
      var agent = new HttpsProxyAgent(proxy);
      options.headers["proxy-connection"]="Keep-Alive";
      options.agent = agent;

    }else{
      options.host=this.proxyHost; // proxy hostname
      options.port=this.proxyPort; // proxy port
      options.headers.host=this.host+":"+this.port;
    }
  };
  var client=this.isSecure?https:http;
  var req=client.request(options, (res) => {
    var rawData='';
    res.on('data', (chunk) => { rawData += chunk; });
    res.on('end', () => {
    //  console.log("res.headers:%s",JSON.stringify(res.headers));
      var contentType=res.headers['content-type'];
      //console.log("client response:status=%s,body=%s",res.statusCode,res.body);
      if(contentType==='application/json'){
        res.body=JSON.parse(rawData);
      }else{
        res.body=rawData;
      }

      callback(null,res);
    });
    res.on('error', (e) => {
      console.error(`client error: ${e.message}`);
      callback(e,null)
    });
  });
  req.on('error', (e) => {
    console.error(`problem with request: ${e.message}`);
    callback(e,null)
  });
  if(data){
    var str=typeof data==='string'?data:JSON.stringify(data);
    req.write(str);
  }
  req.end();
}

HttpClient.prototype.get=function(path,headers,callback){
  this.doRequest('GET',path,headers,null,callback)
}
HttpClient.prototype.put=function(path,headers,data,callback){
  this.doRequest('PUT',path,headers,data,callback)
}
HttpClient.prototype.post=function(path,headers,data,callback){
  this.doRequest('POST',path,headers,data,callback)
}
HttpClient.prototype.del=function(path,headers,callback){
  this.doRequest('DELETE',path,headers,null,callback)
}

module.exports=HttpClient;
