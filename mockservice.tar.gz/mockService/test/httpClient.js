var http=require('http');
var https=require('https');
var tls = require('tls');
var HttpsProxyAgent = require('https-proxy-agent');
var proxyHost="localhost";
var proxyPort=8080;

function httpRequest(options,callback,useProxy){
  var myoptions=options;
  if(useProxy){
    myoptions = {
      host: proxyHost || "localhost", // proxy hostname
      port: proxyPort || 8080,  // proxy port
      method:options.method || 'GET',
      path: options.path,
      // headers: {
      //   host: options.host+":"+options.port,
      //   "proxy-connection":"Keep-Alive"
      // }
    };
    myoptions.headers=options.headers;
    myoptions.headers.host=options.host+":"+options.port;
  }
//  console.log("http client options:%s",JSON.stringify(myoptions))
  var req=http.request(myoptions, (res) => {
    var rawData='';
    res.on('data', (chunk) => { rawData += chunk; });
    res.on('end', () => {
      res.body=rawData;
//      console.log("client response:status=%s,body=%s",res.statusCode,res.body);
      callback(null,res);
    });
    res.on('error', (e) => {
      console.error(`client error: ${e.message}`);
      callback(e,null)
    });
  });
  req.on('error', (e) => {
    console.error(`problem with request: ${e.message}`);
    callback(e,null)
  });
//  req.write(postData);
  req.end();
}
function httpsRequest(options,callback,useProxy){
  if(useProxy){
    var proxy = 'http://'+proxyHost+':'+proxyPort;
    var agent = new HttpsProxyAgent(proxy);
    options.headers["proxy-connection"]="Keep-Alive";
    options.agent = agent;
  }
  var req=https.request(options, (res) => {
    var rawData='';
    res.on('data', (chunk) => { rawData += chunk; });
    res.on('end', () => {
      res.body=rawData;
      console.log("https client response:status=%s,body=%s",res.statusCode,res.body);
      callback(null,res);
    });
    res.on('error', (e) => {
      console.error(`https client error: ${e.message}`);
      callback(e,null)
    });
  });
  req.on('error', (e) => {
    console.error(`problem with request: ${e.message}`);
    callback(e,null)
  });
//  req.write(postData);
  req.end();
}

function doRequest(options,callback,useProxy){
  var isSecure= typeof options.rejectUnauthorized !='undefined';
  isSecure?httpsRequest(options,callback,useProxy):httpRequest(options,callback,useProxy);
}
exports.request=doRequest;
