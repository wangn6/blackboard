var fs=require('fs');
var should=require('should');
var async=require('async');
var assertObj=require('./assertObj.js').assertObj
var MockServer=require("../MockServer.js");
var TestStore=require("../admin/ServerStore.js");
var ControlPanel=require("../admin/ControlPanel.js");

var route=require('../route.js');

function assertServer(mockServer,expected){
  mockServer.getName().should.equal(expected.key);
  mockServer.getVersion().should.equal(expected.version);
  mockServer.isMocking().should.be.true();
  assertObj(mockServer.getData(),expected.data);
}
function testStartServer(key,version,expected,done){
  controlPanel.startServer(key,version,function(err,mockServer){
    should(err).null();
    assertServer(mockServer,{key:key,version:version,data:expected});
    done()
  })
}
function testStartServerError(key,version,expected,done){
  controlPanel.startServer(key,version,function(err,mockServer){
    err.should.equal(expected);
    done()
  })
}
function testStopServer(key,expected,done){
  controlPanel.stopServer(key,function(err,mockServer){
    should(err).null();
    assertServer(mockServer,expected);
    done()
  })
}
function testStopServerError(key,expected,done){
  controlPanel.stopServer(key,function(err,mockServer){
    err.should.equal(expected);
    done()
  })
}

function testListServers(expected,done){
  function assertServers(results,expecteds){
    results.forEach(function(elm,index){
      var expected=expecteds[index]
      elm.name.should.equal(expected.name);
      if(expected.version){
        elm.version.should.equal(expected.version);
      }
      if(expected.versions){
        assertObj(elm.versions,expected.versions);
      }
    })
  }
  controlPanel.listServers(function(err,map){
    should(err).null();
    console.log("flat map:%s",JSON.stringify(map))

    assertServers(map.recordings,expected.recordings);
    assertServers(map.mockings,expected.mockings);
    assertServers(map.archived,expected.archived);
    done();
  })
}
var controlPanel,testStore;
describe('Test ControlPanel',function() {
  var DB_PATH='./tmp';
  var servers=[
    {key:"www.test.com",version:'v1',data:{v1:'v1 cached data'}},
    {key:"www.test.com",version:'v2',data:{v2:'v2 cached data'}},
    {key:"www.test.com:80",version:'v3',data:{v3:'v3 cached data'}},
  ];
  before(function(){
    testStore=new TestStore(DB_PATH);
    controlPanel=new ControlPanel(testStore.getStore());
  });
  after(function(){
    testStore.clear(function(err){
        console.log("clear test Store :",err);
    })
  });
  step('startServer: start a new server, server should in mock mode', function(done) {
    testStore.prepare(servers,function(err,data){
      should(err).be.null();
      testStartServer("www.test.com",'v1',{v1:'v1 cached data'},done)
    })
  });
  step('startServer: start a same version server should be OK', function(done) {
      testStartServer("www.test.com",'v1',{v1:'v1 cached data'},done)
  });
  step('startServer: start a second server of different version should fail', function(done) {
      testStartServerError("www.test.com",'v2',"ERR_SERVER_ALREADY_RUNNING",done)
  });
  step('startServer: start a NOT exist server should fail', function(done) {
      testStartServerError("www.test.com",'v3','ERR_SERVER_NOT_EXIST',done)
  });
  step('startServer: start a different server should be OK', function(done) {
      testStartServer("www.test.com:80",'v3',{v3:'v3 cached data'},done)
  });
  step('stopServer: stop a running server should be OK', function(done) {
      testStopServer("www.test.com:80",{key:"www.test.com:80",version:'v3',data:{v3:'v3 cached data'}},done)
  });
  step('stopServer: stop a not running server should fail', function(done) {
      testStopServerError("www.test.com:80","ERR_SERVER_NOT_RUNNING",done)
  });
  step('listServers: verify running and archived server', function(done) {
      testListServers({
           recordings:[],
           mockings:[{name:'www.test.com',version:'v1',startedTime:"",stoppedTime:""}],
           archived:[{name:'www.test.com',versions:['v1','v2']},{name:'www.test.com:80',versions:['v3']}]
         },done)
  });
});
