var async=require('async');
var should=require('should');
var httpClient=require('./httpClient.js');
var AdminClient=require('./adminClient.js');

function assertResponse(result,expected){
  result.statusCode.should.equal(expected.statusCode);
  var headers=expected.headers;
  if(headers && headers.cookie )
    result.headers.cookie.should.equal(headers.cookie);
  if(expected.body)
    result.body.should.equal(expected.body);
}

function requestOption(testOption){
  var options = {
    host: testOption.hostname, // proxy hostname
    port: testOption.port,  // proxy port
    method:testOption.method || 'GET',
    path: testOption.path,
    headers: {
      host: testOption.hostname+":"+testOption.port
    }
  };
  if(testOption.headers){
    options.headers=testOption.headers;
    options.headers.host=testOption.hostname+":"+testOption.port
  }
  if(testOption.secure){
    options["rejectUnauthorized"]=false;
  }
  return options;
}
function recording(myReq,callback){
  httpClient.request(myReq.options, (err,res) => {
    myReq.res=res;
    if(myReq.expected)
      assertResponse(res,myReq.expected);
    callback();
  },true)
}
function mocking(myReq,callback){
  httpClient.request(myReq.options, (err,res) => {
    var expected=myReq.res;
    assertResponse(res,expected);
    callback()
  },true)
}
function mycallback(callback,msg){
  return function(err){
    if(err){
      console.log(msg,err);
      callback(err,null);
    }
    else{
      console.log(msg+" done!")
      callback(null,msg+" done!");
    }
  }
}
var adminClient=new AdminClient();
/**
{
 req:{method:"GET",hostname:"",path:"http://hostname:port/hello",headers:{},secure:false,data:OPTIONAL}
 res:{
  status:200,body:"",headers:""
 }
}
*/
function recordAndMock(rrList,done){

  var myReqs=rrList.map(function(elm){
    return {options:requestOption(elm.req),expected:elm.res};
  });
  async.series([
    function(callback){ // assure server is in recording mode
      console.log("Recording...");
      adminClient.record(callback);
    },
    function(callback) {
        async.each(myReqs,recording, mycallback(callback,"recording"));
    },
    function(callback){
      console.log("swithToMocking");
      adminClient.mock(callback);
    },
    function(callback) {
      console.log("Mocking...");
        async.each(myReqs, mocking, mycallback(callback,"mocking"));
    }
  ],
  // optional callback
  function(err, results) {
      console.log("recordAndMock err:",err)
  //    console.log("record and mock:%s",JSON.stringify(results))
  //    if(results)
        done();
  });
}
exports.recordAndMock=recordAndMock;
