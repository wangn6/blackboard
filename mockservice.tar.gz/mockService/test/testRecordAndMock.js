const fs = require('fs');
var testClient=require("./testClient.js");
var proxyServer=require("../proxyServer.js");

const BlankServer=require("../blankServer/BlankServer.js");
const echoApps=require("../blankServer/echoApps.js");
const Apps=require("../blankServer/apps2.js");

var httpPort=8082;
var securePort=8443;
var apps=new Apps();
var secureApps=new Apps();
var testServer=new BlankServer("Test Server",apps,secureApps);

function isSecure(req){
  return true===req.secure
}
function setTestServer(rrList){
  rrList.forEach(function(rr){
    if(isSecure(rr.req)){
        echoApps.echo(secureApps,rr);
    }else{
      echoApps.echo(apps,rr);
    }
  })
}
function test(rrList,done){
  setTestServer(rrList);
  var myReqs=rrList.map(function(rr){
    var req=rr.req;
    var secure=isSecure(req);
    return {req:{secure:secure,hostname:"localhost",port:secure?securePort:httpPort,method:req.method,path:req.path,headers:req.headers},res:rr.res};
  })
  testClient.recordAndMock(myReqs,done)
}
const options = {
  key: fs.readFileSync('../cert/mockservice.key'),
  cert: fs.readFileSync('../cert/mockservice.crt')
};
describe('Test Recording and Mocking ', function() {
  before(function() {
    testServer.startHttp(httpPort);
    testServer.startHttps(securePort,options);
  });
  it('HTTP same path to one host with Get POST PUT', function(done) {
    test([{req:{path:"/hello/a/1"},res:{statusCode:200,body:"get hello/a/1"}},
          {req:{method:"POST",path:"/hello/a/1"},res:{statusCode:200,body:"post hello/a/1"}},
          {req:{method:"PUT",path:"/hello/a/1"},res:{statusCode:200,body:"put hello/a/1"}},
          ],done)
  });
  it('HTTPS same path to one host with Get POST PUT', function(done) {
    test([{req:{path:"/hello/a/1",secure:true},res:{statusCode:200,body:"get hello/a/1"}},
          {req:{method:"POST",path:"/hello/a/1",secure:true},res:{statusCode:200,body:"post hello/a/1"}},
          {req:{method:"PUT",path:"/hello/a/1",secure:true},res:{statusCode:200,body:"put hello/a/1"}},
          ],done)
  });
  it('same path with same host but different port', function(done) {
    test([{req:{path:"/hello/a/1",secure:true},res:{statusCode:200,body:"secure get hello/a/1"}},
          {req:{path:"/hello/a/1",secure:false},res:{statusCode:200,body:"plain get hello/a/1"}}],done)
  });
  it('same path with different cookies', function(done) {
    test([{req:{path:"/test/cookie",headers:{"cookie":"ck1=a; ck2=b"}},res:{statusCode:200,body:"cookie a b"}},
          {req:{path:"/test/cookie",headers:{"cookie":"ck1=a; ck2=c"}},res:{statusCode:200,body:"cookie a c"}},
          ],done)
  });
  it('HTTPS same path with different cookies', function(done) {
    test([{req:{path:"/test/cookie",secure:true,headers:{"cookie":"ck1=a; ck2=b"}},res:{statusCode:200,body:"cookie a b"}},
          {req:{path:"/test/cookie",secure:true,headers:{"cookie":"ck1=a; ck2=c"}},res:{statusCode:200,body:"cookie a c"}},
          ],done)
  });
  it('same path to different hostname with same port')
});
