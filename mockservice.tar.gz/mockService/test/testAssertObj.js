var test=require('./assertObj.js').assertObj
describe('Test assertObj', function() {
  it("aBc", function() {
    test('aBc','aBc')
  });
  it("{a:'A',b:'B'}", function() {
    test({a:'A',b:'B'},{a:'A',b:'B'})
  });
  it("{a:'A',b:'B'}=={b:'B',a:'A'}", function() {
    test({a:'A',b:'B'},{b:'B',a:'A'})
  });
  it('[A,1]', function() {
    test(['A',1],['A',1])
  });
  it("{key:'A',data:[{seq:1,desc:'1a'},{seq:2,desc:'1b'}]", function() {
    test({key:'A',data:[{seq:1,desc:'1a'},{seq:2,desc:'1b'}]},{key:'A',data:[{seq:1,desc:'1a'},{seq:2,desc:'1b'}]})
  });
  it('[{name:"A",age:1},{name:"B",age:2}]', function() {
    test([{name:"A",age:1},{name:"B",age:2}],[{name:"A",age:1},{name:"B",age:2}])
  });
});
