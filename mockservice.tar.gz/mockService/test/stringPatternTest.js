
var pattern2=/\/path\/to\/{(.+)}\/and\/{(.+)}/
var re=new RegExp("/path/to/{(.+)}/and/{(.+)}");
var str="/path/to/{param1}/and/{param2}";
var strNoParam="/path/to/A/and/B";


var str_miss_param="/path/to/{param1}/and/";
function match(str,pattern){
  var matches=str.match(pattern);
  console.log("matches:%s",JSON.stringify(matches))
}
function strtoPattern1(str){
//  var re=new RegExp('{\\w+}','g')
  var re=/{\w+}/g
  var pstr=str.replace(re,'(w+)');
  console.log("Pattern string:%s",pstr)
}
function getParams(strs){
  if(strs){
    return strs.map(function(str){
      return str.substring(1,str.length-1);
    })
  }else {
    return [];
  }

}
function strtoPattern(str){
  var re=new RegExp('{\\w+}','g')
//  var re=/\{(\w+)\}/g
  var params=getParams(str.match(re));
  var pstr=str.replace(re,'(\\w+)');
  console.log("Pattern string:%s",pstr);
  console.log("Params: %s",JSON.stringify(params))
  return new RegExp(pstr);
}
// match(str,re);
// match(str_miss_param,re);
match(strNoParam,strtoPattern(str));
//strtoPattern(strNoParam)
