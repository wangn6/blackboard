var fs=require('fs');
var should=require('should');
var async=require('async');
var FileDb=require("../db/FileDb.js");
var IndexStore=require("../db/IndexStore.js");

var assertObj=require('./assertObj.js').assertObj

var db
function addIdx(idxArr,onComplete){
  async.eachSeries(idxArr,function(idx,callback){
    db.put(idx.key,idx.version,idx.url,idx.data,function(err){
        callback(err);
    })
  },onComplete)
}

function testAdd(idxArr,expected,done){
  addIdx(idxArr,function(err){
    should(err).null();
    db.list(function(err,data){
      should(err).null();
  //    console.log("idxmap:%s",JSON.stringify(data));
      assertObj(data,expected)
      done();
    })
  })
}
function testGet(key,version,expected,done){
    db.get(key,version,function(err,data){
      should(err).null();
  //    console.log("idx get:%s",JSON.stringify(data));
      assertObj(data,expected);
      done();
    })
}
function testDel(key,version,expected,done){
    db.del(key,version,function(err){
      should(err).null();
      db.list(function(err,data){
        should(err).null();
  //      console.log("idxmap:%s",JSON.stringify(data));
        assertObj(data,expected)
        done();
      })
    })
}
describe('Test IndexStore', function() {
  var DB_PATH='./tmp';
  before(function() {
    if(!fs.existsSync(DB_PATH))
      fs.mkdirSync(DB_PATH)
    db=new IndexStore(new FileDb(DB_PATH));
  });
  after(function(){
    db.clear(function(err){
      fs.rmdirSync(DB_PATH)
    })

  });
  it('create idx with two versions', function(done) {
    testAdd([
      {key:"www.test.com",version:"v1",url:"www.test.com-v1",data:null},
      {key:"www.test.com",version:"v2",url:"www.test.com-v2",data:{}}
    ],{"www.test.com":[{version:"v1",url:"www.test.com-v1"},{version:"v2",url:"www.test.com-v2"}]},done)
  });
  it('get one verion of idx', function(done) {
    testGet("www.test.com","v1",{version:"v1",url:"www.test.com-v1"},done)
  });
  it('get latest verion of idx', function(done) {
    testGet("www.test.com",null,{version:"v2",url:"www.test.com-v2"},done)
  });
  it('delete one verion', function(done) {
    testDel("www.test.com","v1",{"www.test.com":[{version:"v2",url:"www.test.com-v2"}]},done)
  });
});
