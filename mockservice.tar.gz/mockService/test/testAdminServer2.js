var should=require('should');
var AdminClient=require("./AdminClient2.js");
var adminServer=require("../admin/adminServer2.js");
var assertObj=require('./assertObj.js').assertObj;
var TestStore=require("../admin/ServerStore.js");
function assertResponse(res,status,body){
  //console.log("status:%d body:%s",result.statusCode,result.body);
//  console.log("body:%s",JSON.stringify(res.body));
  res.statusCode.should.equal(status);
  assertObj(res.body,body)
}
function assertServer(res,status,body){
  //console.log("status:%d body:%s",result.statusCode,result.body);
//  console.log("body:%s",JSON.stringify(res.body));
  res.statusCode.should.equal(status);
  if(typeof res.body==='string'){
    res.body.should.equal(body);
  }else{
    res.body.name.should.equal(body.name);
    res.body.version.should.equal(body.version);
  }

}

describe('Test Admin Server', function() {
  var port=18081;
  var servers=[
    {key:"www.test.com",version:'v1',data:{v1:'v1 cached data'}},
    {key:"www.test.com",version:'v2',data:{v2:'v2 cached data'}},
    {key:"www.test.com:80",version:'v3',data:{v3:'v3 cached data'}},
  ];
  var client=new AdminClient(port);
  var testStore
  after(function(){
    testStore.clear(function(err){
        console.log("clear test Store :",err);
    })
  });
  step('prepare data and start admin server',function(done) {
    testStore=new TestStore('./tmp');
    testStore.prepare(servers,function(err){
      should(err).null();
      console.log("Test store prepare data done.:",err)
      adminServer.start(port,testStore.getStore());
      done()
    })
  });

  step('listServer success', function(done) {
    client.listServer(function(err,res){
        should(err).null();
        assertResponse(res,200,{
             recordings:[],
             mockings:[],
             archived:[{name:'www.test.com',versions:['v1','v2']},{name:'www.test.com:80',versions:['v3']}]
           });
        done()
    })
  });
  step('startServer: start a new server, server should in mock mode', function(done) {
    client.startServer("www.test.com","v1",function(err,res){
        should(err).null();
        assertServer(res,200,{name:"www.test.com",version:"v1",started:""});
        done()
    })
  });
  step('startServer: start same server should success', function(done) {
    client.startServer("www.test.com","v1",function(err,res){
        should(err).null();
        assertServer(res,200,{name:"www.test.com",version:"v1",started:""});
        done()
    })
  });
  step('startServer: start same server of different version should fail with ERR_SERVER_ALREADY_RUNNING', function(done) {
    client.startServer("www.test.com","v2",function(err,res){
        should(err).null();
        assertServer(res,400,"ERR_SERVER_ALREADY_RUNNING");
        done()
    })
  });
  step('stoptServer: stop a running server should success', function(done) {
    client.stopServer("www.test.com",function(err,res){
        should(err).null();
        assertServer(res,200,{name:"www.test.com",version:"v1",started:""});
        done()
    })
  });
  step('stoptServer: stop a NOT running server should fail with ERR_SERVER_NOT_RUNNING', function(done) {
    client.stopServer("www.test.com:80",function(err,res){
        should(err).null();
        assertServer(res,400,"ERR_SERVER_NOT_RUNNING");
        done()
    })
  });
  step('startServer: start server of latest verion(no version is specified) should success', function(done) {
    client.startServer("www.test.com",null,function(err,res){
        should(err).null();
        assertServer(res,200,{name:"www.test.com",version:"v2",started:""});
        done()
    })
  });
});
