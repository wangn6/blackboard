const fs = require('fs');
var should=require('should');
var async=require('async');
var HttpClient=require("./HttpClient2.js");
var route=require("../route.js");
var proxyServer=require("../proxyServer2.js");
var assertObj=require('./assertObj.js').assertObj;
const EchoServer=require("../blankServer/EchoServer.js");
var adminServer=require("../admin/adminServer2.js");
var AdminClient=require('./AdminClient2.js');
var TestStore=require("../admin/ServerStore.js");

var httpPort=8082;
var securePort=8443;
var proxyPort=8080;
var adminPort=8081;
var plainClient=new HttpClient('localhost',httpPort,false,'localhost',proxyPort);
var adminClient=new AdminClient(adminPort)
function assertResponse(expected,done){
  function assertHeaders(result,expected){
    var keys=Object.keys(expected);
    keys.forEach(function(key){
       result[key].should.equal(expected[key]);
    })
  }
  return function(err,res){
    should(err).null();
    res.statusCode.should.equal(expected.statusCode);
    if(expected.headers){
      assertHeaders(res.headers,expected.headers);
    }
    if(typeof expected.body==='string'){
      res.body.should.equal(expected.body);
    }else{
      assertObj(res.body,expected.body);
    }
    done()
  }
}
function accessServer(rr,callback){
  var req=rr.req;
  var res=rr.res
  plainClient.doRequest(req.method,req.path,req.headers,null,assertResponse(res,callback))
}
const httpsOptions = {
  key: fs.readFileSync('../cert/mockservice.key'),
  cert: fs.readFileSync('../cert/mockservice.crt')
};
describe('Test Recording and Mocking ', function() {
  var rrList=[{req:{path:"/hello/a/1"},res:{statusCode:201,headers:{"content-type": "text/xml; charset=utf-8"},body:"get hello/a/1"}},
            {req:{method:"POST",path:"/hello/a/1"},res:{statusCode:200,body:"post hello/a/1"}},
            {req:{method:"PUT",path:"/hello/a/1"},res:{statusCode:200,body:"put hello/a/1"}},
            {req:{method:"DELETE",path:"/hello/a/1"},res:{statusCode:200,body:"put hello/a/1"}},
        ]
  var testServer=new EchoServer("Test Echo Server");
  testServer.prepare(rrList);
  var testStore=new TestStore('./tmp');
  after(function(){
    testStore.clear(function(err){
        console.log("clear test Store :",err);
    })
  });
  step('start proxyServer,Admin Server, echo server',function() {
    testServer.start(httpPort);
    proxyServer.start(route,proxyPort,8088,httpsOptions);
    adminServer.start(adminPort,testStore.getStore());
  });
  step('Do Recording success with GET/POST/PUT/DELETE to same path', function(done) {
    async.each(rrList,accessServer,done)
  });
  step('Change to Mocking mode success', function(done) {
    async.series([
        function(callback){ // assure server is in recording mode
            console.log("Stop recording");
            adminClient.stopServer('localhost:8082',function(err,mockServerInfo){
                should(err).null();
                callback(err);
            })
        },
        function(callback){ // assure server is in recording mode
            console.log("Start Mocking");
            adminClient.startServer('localhost:8082',null,function(err,mockServerInfo){
                should(err).null();
                callback(err);
            })
        },
      ],done)
  });
  step('Access Mocking server success', function(done) {
    async.each(rrList,accessServer,done)
  });
});
