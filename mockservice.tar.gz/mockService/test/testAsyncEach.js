var fs=require('fs');
var path=require('path');
var should=require('should');
var asyncEach=require('../db/asyncEach.js').each;
var assertObj=require('./assertObj.js').assertObj
function test(data,expected,func,done){
  asyncEach(data,func,function(err,results){
  //  console.log("results:%s",JSON.stringify(results))
      should(err).null();
      assertObj(results,expected);
      done()
  })
}
function testFile(data,expected,done){
  function createFile(elm,callback){
    fs.writeFile(path.join(TMPDIR,elm.name),elm.value,function(err){callback(err,null)})
  }
  function readFile(elm,callback){
    var filename=path.join(TMPDIR,elm.name);
    fs.readFile(filename,'utf8',function(err,data){
      fs.unlink(filename,function(err){callback(err,data)})
    })
  }
  function assertFileCreated(){
    asyncEach(data,readFile,function(err,results){
        should(err).null();
        assertObj(results,expected);
        done()
    })
  }
  asyncEach(data,createFile,function(err,results){
      assertFileCreated()
  })
}
const TMPDIR='./tmpAsync';
describe('Test asyncEach', function() {
  before(function(){
    if(!fs.existsSync(TMPDIR))
      fs.mkdirSync(TMPDIR)
  })
  after(function(){
    fs.rmdirSync(TMPDIR)
  })
  it("[1,2]", function(done) {
    function echo(data,callback){ callback(null,"echo "+data)}
    test([1,2],{"0":"echo 1","1":"echo 2"},echo,done)
  });
  it("{a:1,b:2}", function(done) {
    function echo(data,callback){ callback(null,"echo "+data)}
    test({a:1,b:2},{"a":"echo 1","b":"echo 2"},echo,done)
  });
  it("create two dir", function(done) {
      testFile({a:{name:'a.txt',value:'a test'},b:{name:'b.txt',value:'b test'}},
      {a:'a test',b:'b test'},done)
  });
});
