var should=require('should');
function assertObj(obj,expected){
  if(typeof obj==='object'){
    var keys=Object.keys(obj);
    var expKeys=Object.keys(expected);
    keys.length.should.equal(expKeys.length);
    keys.forEach(function(key){
      if(typeof expected[key]==='object'){
        if(expected[key]){
          assertObj(obj[key],expected[key]);
        }else{
          should(obj[key]).null();
        }
      }else {
        obj[key].should.equal(expected[key])
      }
    })
  }else{
    obj.should.equal(expected)
  }

}
exports.assertObj=assertObj
