function cookies(request){
  var cookies=request.headers.cookie;
  //console.log("cookie:%s",cookies);
  return typeof cookies!='undefined'?' '+cookies:'';
}
function getKey(request){
//  console.log("MemCache get request:%s",JSON.stringify(request))
  var path=request.path;
  var method=request.method;
  return method+" "+path+cookies(request);
}
function MemCache(data){
  this.memMap=data || {}
}
function putData(map,key,value){
  map[key]=value;
}
MemCache.prototype.put=function(request,response){
    var key=getKey(request)
    putData(this.memMap,key,{req:request,res:response});
}
MemCache.prototype.get=function(request){
    var key=getKey(request);
    var cache=this.memMap[key];
    if(cache){
      return {key:key,data:cache.res};
    }
    return null;
}
MemCache.prototype.getAll=function(){
    return this.memMap;
}
module.exports=MemCache
