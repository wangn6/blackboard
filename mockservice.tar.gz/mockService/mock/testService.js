var proxyRequestParser=require("./proxyRequestParser.js");
function sendResponse(response,status,body,headers){
  response.writeHead(status,headers);
  response.write(body);
  response.end();
}
function doResponse(res, response, delayMode){
  if (delayMode && res.elapse){
    var delay=res.elapse*delayMode;
    setTimeout(function(){
      sendResponse(response,res.status,res.body,res.headers)
      console.log("delayed response %d", expense);
    },delay)
  }else{
   sendResponse(response,res.status,res.body,res.headers)
  }
}
function start(store,delay){
  return function(request, response){
    var reqOptions=proxyRequestParser(request);
    var cache=store.get(reqOptions);
    if(cache){
      var res=cache.data;
      doResponse(res, response, delay)
    }else{
      console.log("MockServer : key=%s missed",cache.key);
      response.writeHead(404,"Mock Server missed");
      response.end("404 Mock Server missed");
    }
  }
}
exports.start=start;
exports.serviceName=function(){
  return "Test Service";
};
