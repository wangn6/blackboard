var store=require("../memStore.js");
var proxyRequestParser=require("./proxyRequestParser.js");
function sendResponse(response,status,body,headers){
  response.writeHead(status,headers);
  response.write(body);
  response.end();
}
function doResponse(res, response, delayMode){
  if (delayMode>0){
    var delay=res.elapse*delayMode;
    setTimeout(function(){
      sendResponse(response,res.status,res.body,res.headers)
      console.log("delay response %d", expense);
    },delay)
  }else{
   sendResponse(response,res.status,res.body,res.headers)
  }
}

function service(request, response){
  var reqOptions=proxyRequestParser(request);
  var cache=store.get(reqOptions);
  if(cache){
    var res=cache.data;
    console.log("MockServer : key=%s response=%s",cache.key, res.body);
    res.headers["X-CACHE-HIT"]=cache.key;
    response.writeHead(res.status,res.headers);
    response.write(res.body);
    response.end();
  }else{
    console.log("MockServer : key=%s missed",cache.key);
    response.writeHead(404,"Mock Server missed");
    response.end("404 Mock Server missed");
  }
}

exports.run=service;
exports.serviceName=function(){
  return "MockService";
};
// exports.start=function(onComplete){
//   store.load(onComplete);
// };
// module.exports=function(db){
//   console.log("mockService use db %s",db);
//   console.log("mockService use db: %s",JSON.stringify(memStore.getAll()));
//   return service
// }
