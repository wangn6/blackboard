function getOptions(request){
  var rawHost=request.headers['host'];
  var strs=rawHost.split(":");
  var destHost=strs[0];
  var destPort=strs[1] || 80;
  var options={
        hostname: destHost,
        port:destPort,
        path:request.url,//request.path,//
        method:request.method,
        headers: request.headers
      };
  return options;
}
module.exports=getOptions;
