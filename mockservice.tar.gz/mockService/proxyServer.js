const http = require('http');
const net= require('net');
const https = require('https');
const fs = require('fs');
var services=require("./services.js");
function startHttps(httpsPort){
  const options = {
    key: fs.readFileSync('./cert/mockservice.key'),
    cert: fs.readFileSync('./cert/mockservice.crt')
  };
  https.createServer(options, (req, res) => {
    console.log("HTTPS receive req:%s",req.url )
    services.run(req, res);
  }).listen(httpsPort);
  console.log("Proxy Server HTTPS listening on %d",httpsPort)
}
function onConnect(proxy,httpsPort){
  proxy.on('connect', (req, cltSocket, head) => {
      // console.log("Proxy Server on connect url:%s,",req.url);
      // console.log("Proxy Server on connect head:%s,",head);
      // connect to an origin server
      //const srvUrl = url.parse(`http://${req.url}`);
      var hostname="localhost";
      const srvSocket = net.connect(httpsPort,hostname, () => {
          cltSocket.write('HTTP/1.1 200 Connection Established\r\n' +
                          'Proxy-agent: Node.js-Proxy\r\n' +
                          '\r\n');
          srvSocket.write(head);
          srvSocket.pipe(cltSocket);
          cltSocket.pipe(srvSocket);
        });
    });
}

exports.start=function(port,httpsPort){
  var proxyPort=port || 8080;
  var proxyServer=http.createServer(function(request, response) {
    services.run(request, response);
  }).listen(proxyPort);
  onConnect(proxyServer,httpsPort || 8088);
  console.log("Proxy Server started listening on %d",proxyPort);
  startHttps(httpsPort || 8088);
}
