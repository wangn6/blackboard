const gulp = require('gulp');
const tar = require('gulp-tar');
const gzip = require('gulp-gzip');
var scp = require('gulp-scp');
var user=require("os").userInfo().username;
var hostToDeploy="virdev+mock";
gulp.task("deploy",['tar'],()=>
    gulp.src('./dist/mockservice.tar.gz')
        .pipe(scp({host:hostToDeploy,user:user,path:'~'}))
);
gulp.task('tar', () =>
    gulp.src(['./**/*.js','cert/**','!node_modules/**','!store/**', '!trash/*'],{ base: '..' })
        .pipe(tar('mockservice.tar'))
        .pipe(gzip())
        .pipe(gulp.dest('./dist'))
);
