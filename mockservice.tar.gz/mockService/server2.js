const fs = require('fs');
const path = require('path');
var adminServer=require("./admin/adminServer2.js");
var ServerStore=require("./admin/ServerStore.js");
var proxyServer=require("./proxyServer2.js");
var route=require("./route.js");
var DB_PATH='./data';
var serverStore=new ServerStore(DB_PATH);
var proxyPort=process.env.proxyPort || 8080;
var adminPort=process.env.adminPort || 8081;
var securePort=process.env.securePort || 8088;
const httpsOptions = {
  key: fs.readFileSync(path.join(__dirname,'./cert/mockservice.key')),
  cert: fs.readFileSync(path.join(__dirname,'./cert/mockservice.crt'))
};
var staticOptions={path:'/',baseDir:path.join(__dirname,'../mock-service-webclient/public')}
adminServer.start(adminPort,serverStore.getStore(),staticOptions);
proxyServer.start(route,proxyPort,securePort,httpsOptions);
