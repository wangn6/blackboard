var MockServer=require("./MockServer.js");
var serverMap=new Map();
/**
serverMap={
  "hostname:port":MockServer

}
**/
function addServer(server){
  server.start();
  serverMap.set(server.getName(),server);
  console.log("Route Add server: %s.",server.getName());
}

exports.run=function(request, response){
//  console.log("%s is running:%s \n",currentService.serviceName(),request.url);
  var serverName=request.headers['host'];
  if(serverName){
    var server=serverMap.get(serverName);
    if(!server){
      server=new MockServer(serverName,new Date());
      addServer(server);
    }
    server.run(request, response);
  }else{
    var err="request has no host header!";
    response.writeHead(400);
    response.end(err);
  }

}
exports.get=function(serverName){
  return serverMap.get(serverName)
}
/**
return True , successfully added
return false, failed to add
**/
exports.add=function(mockServer){
  var serverName=mockServer.getName();
  var server=serverMap.get(serverName);
  if(!server){
    addServer(mockServer);
    // console.log("route size:%d",serverMap.size);
    // console.log("route map:%s",JSON.stringify(Array.from(serverMap.entries())))
    return true;
  }else{
    return false;
  }
}
/**
return Server , successfully removed
return null, server not found
**/
exports.remove=function(serverName){
//  console.log("%s is running:%s \n",currentService.serviceName(),request.url);
 var server=serverMap.get(serverName);
 if(server){
   server.stop();
   serverMap.delete(serverName);
   console.log("Route removed server %s .",serverName);
 }
 return server;
}
/**
return list of mock servers
**/
exports.list=function(){
  var result={}
  serverMap.forEach(function(value, key) {
    result[key]=value;
  });
 return result;
}
