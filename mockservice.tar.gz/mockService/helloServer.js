const fs = require('fs');
const path = require('path');
const BlankServer=require("./blankServer/BlankServer.js");
const echoApps=require("./blankServer/echoApps.js");
const Apps=require("./blankServer/apps2.js");

var rrlistPlain=[
  {req:{path:"/mock",method:"GET",headers:""},res:{statusCode:200,body:"echo mock"}},
  {req:{path:"/hello/a/1"},res:{statusCode:200,body:"echo hello/a/1"}},
  {req:{path:"/hello/a/2"},res:{body:"echo hello/a/2"}},
]
var rrlistSecure=[
  {req:{path:"/mock",method:"GET",headers:""},res:{statusCode:200,body:"secure echo mock"}},
  {req:{path:"/hello/a/1"},res:{statusCode:200,body:"secure echo hello/a/1"}},
  {req:{path:"/hello/a/2"},res:{body:"secure echo hello/a/2"}},
]
var apps=new Apps();
var secureApps=new Apps();
const httpsOptions = {
  key: fs.readFileSync(path.join(__dirname,'./cert/mockservice.key')),
  cert: fs.readFileSync(path.join(__dirname,'./cert/mockservice.crt'))
};
echoApps.echo(apps,rrlistPlain);
echoApps.echo(secureApps,rrlistSecure);
var helloServer=new BlankServer("Hello Server",apps,secureApps);
helloServer.startHttp(8082);
helloServer.startHttps(8443,httpsOptions);
