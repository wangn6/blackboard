var mockService=require("./mock/mockService.js");
var proxyService=require("./proxy/proxyService.js");
var currentService=proxyService;
function log(){
  console.log("%s is ready.\n",currentService.serviceName());
}
function isMocking(){
  return currentService.serviceName()===mockService.serviceName()
}
exports.run=function(request, response){
//  console.log("%s is running:%s \n",currentService.serviceName(),request.url);
  currentService.run(request, response);
}
exports.record=function(){
  if(isMocking()){
    currentService=proxyService;
  }
  log();
}
exports.mock=function(){
  if(!isMocking()){
    currentService=mockService;
  }
  log();
}
exports.isMocking=function(){
  return isMocking();
}
// exports.start=function(){
//   mockService.start(function onComplete(err){
//     if(err){// no mock data , then start in Recording mode
//       exports.record();
//     }else{ // mock data is ready , then start in Mock mode
//       exports.mock();
//     }
//   });
//
// }
