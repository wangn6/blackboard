function getParams(strs){// get rid of '{' and '}'
  var result=[]
  if(strs){
    result= strs.map(function(str){
      return str.substring(1,str.length-1);
    })
  }
  return result;
}
var paramPattern=new RegExp('{\\w+}','g');
function ParamStr(str){
  this.str=str;
  this.params=getParams(str.match(paramPattern));
  if(this.params.length>0){
    var pstr=str.replace(paramPattern,'([\\w\\.\\-:]+)');
    this.re=new RegExp('^'+pstr+'$');
  }
}
function zip(keys,values){
  var result=false;
  if(values && keys.length===values.length-1){
    var result={}
    for(var i=0;i<keys.length;i++){
      result[keys[i]]=values[i+1];
    }
  }
  return result;
}
/**
return
  {paramName1:value1,param2:value2} if param string is matched
  true if non-param string is matched
  false if not match
***/
ParamStr.prototype.match=function(str){
  var result= this.hasParameters()? zip(this.params,str.match(this.re)) : this.str===str
//  console.log("Matches:%s",JSON.stringify(result));
  return result;
}
ParamStr.prototype.hasParameters=function(){
  return this.params.length>0;
}
module.exports=ParamStr
