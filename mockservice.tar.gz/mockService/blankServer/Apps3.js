var url = require('url');
var ParamStr=require('./ParamStr.js');
function Apps(){
  this.appTable=[];
  this.errorTable={};
}
Apps.prototype.app=function(method,path,func){
    var httpMethod=method || "GET";
    var mypath=path || '/';
    var item={method:method.toUpperCase(),path:new ParamStr(path),app:func};
    this.appTable.push(item);
  }
Apps.prototype.get=function(path,app){
    this.app("GET",path,app);
  }
Apps.prototype.put=function(path,app){
    this.app("PUT",path,app);;
  }
Apps.prototype.post=function(path,app){
    this.app("POST",path,app);;
  }
Apps.prototype.del=function(path,app){
    this.app("DELETE",path,app);;
  }
Apps.prototype.error=function(errorCode,errorMessage){
    this.errorTable[errorCode]=errorMessage;
  }
//return undefined or  {app:app,params:{}}
function findApp(arr,method,path){
  for(var i=0;i<arr.length;i++){
    var elm=arr[i];
    if(elm.method===method.toUpperCase()){
      var params=elm.path.match(path);
      if(params){
        return {app:elm.app,params:params}
      }
    }
  }
}
function setParams(req,params){
  if(params && typeof params==='object'){
    req.params=params;
  }
}
Apps.prototype.run=function(request, response){
    var self=this;
    var myUrl=url.parse(request.url);
    var pathName=myUrl.pathname;
    var item=findApp(self.appTable,request.method,pathName);
    if(item){
      setParams(request,item.params)
  //    console.log("req params:%s:",JSON.stringify(item.params))
      item.app(request, response);
      return true;
    }
    return false;
}
module.exports=Apps;
