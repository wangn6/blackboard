"use strict";

var fs = require('fs');
var path = require('path');
exports.staticService=function(baseDir){
  var baseLoc=path.resolve(baseDir);
  return function(req, res) {
      var filePath=req.url;
      if(filePath==='/' || filePath===''){
        filePath='/index.html';
      }
      var fileLoc = path.join(baseLoc, filePath);
    //  console.log("static service access file:"+fileLoc);
          var stream = fs.createReadStream(fileLoc);

          // Handle non-existent file
          stream.on('error', function(error) {
              res.writeHead(404, 'Not Found');
              res.write('404: File Not Found!');
              res.end();
          });

          // File exists, stream it to user
          res.statusCode = 200;
          stream.pipe(res);
  };

}
