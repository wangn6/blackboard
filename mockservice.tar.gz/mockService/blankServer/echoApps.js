function echo(resData){
  return function (request,response){
    var headers=resData.headers //|| defaultHeaders;
    var status=resData.statusCode || 200;
    response.writeHead(status,headers);
    response.write(resData.body);
    if(request.body)
      response.write(request.body);
    response.end();
  }
}
function add(apps,rr){
  var req=rr.req;
  var method=req.method || "GET";
  apps.app(method,req.path,echo(rr.res),req.headers);
//  console.log("echoApp Add:%s",JSON.stringify(rr));
}
// rr: {req:{path:"/hello",method:"GET",headers:"",secure:true},res:{status,headers:"",body:""}}
exports.echo=function(apps,rr){
  apps.error(404,"Not Found");
  if(typeof rr.length ==='undefined'){
    add(apps,rr)
  }else{
    rr.forEach(function(elm){
      add(apps,elm)
    })
  }
//  console.log("echoApp:%s",apps.toString());
  return apps;
} ;
