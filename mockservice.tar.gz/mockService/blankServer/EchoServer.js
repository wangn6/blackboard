const BlankServer=require("./BlankServer.js");
const echoApps=require("./echoApps.js");
const Apps=require("./apps2.js");

function EchoServer(name){
  this.secureApps=new Apps();
  this.apps=new Apps();
  this.server=new BlankServer(name,this.apps,this.secureApps);
}
function setList(rrList,apps){
  if(rrList){
    rrList.forEach(function(rr){
          echoApps.echo(apps,rr);
    })
  }
}
EchoServer.prototype.prepare=function(rrList,rrSecureList){
  var self=this;
  setList(rrList,self.apps);
  setList(rrSecureList,self.secureApps);
}
EchoServer.prototype.start=function(port,securePort){
  if(port)
    this.server.startHttp(port)
  if(securePort)
      this.server.startHttps(securePort)
}
module.exports=EchoServer
