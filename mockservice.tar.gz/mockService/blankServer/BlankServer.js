const http = require('http');
const https = require('https');
var staticService=require("./staticService.js").staticService;
/***

staticOptions:{
  path:"/public",
  baseDir:"./"
}
***/
function BlankServer(serverName,apps,secureApps,staticOptions){
  this.serverName=serverName;
  this.apps=apps;
  this.secureApps=secureApps;
  if(staticOptions && staticOptions.baseDir){
      this.staticService=staticService(staticOptions.baseDir);
  }
}
function replyOptionsRequest(response){
//  response.setHeader('Content-Type', 'application/json');
  response.setHeader('Access-Control-Allow-Origin','*');
  response.setHeader('Access-Control-Allow-Headers','Content-Type');
  response.setHeader('Access-Control-Allow-Methods','POST, GET, OPTIONS,DELETE,PUT');
  response.end();
}
function notFound(req,res){
  res.writeHead(404, 'Not Found');
  res.write('404: File Not Found!');
  res.end();
}
function run(apps,staticService,request,response){
  request.body='';
  var self=this;
  request.on('data',function(chunk){
    request.body+=chunk;
  })
  request.on('end',function(){
    if(request.method==='OPTIONS'){// solve CORS problems
//        console.log("[Apps3] replyOptionsRequest headers:%s",JSON.stringify(request.headers));
      replyOptionsRequest(response);
      return;
    }
    if(!apps.run(request,response)){
      if(staticService)
        staticService(request,response)
      else {
        notFound(request,response)
      }
    }
  })
}
BlankServer.prototype.startHttps=function(port,options){
  var self=this;
  https.createServer(options, (req, res) => {
    console.log("%s HTTPS receive req %s",self.serverName,req.url);
    run(self.secureApps,self.staticService,req, res)
  }).listen(port);
  console.log("%s HTTPS listening on %d",self.serverName,port);
}
BlankServer.prototype.startHttp=function(port){
  var self=this;
  var server=http.createServer(function(request, response) {
//    console.log("%s HTTP receive req %s",self.serverName,request.url);
  run(self.apps,self.staticService,request,response)
  });
  server.listen(port);
  console.log("%s HTTP started listening on %d",self.serverName,port);
}
module.exports=BlankServer;
