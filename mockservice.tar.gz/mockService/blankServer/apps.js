var url = require('url');
var appTable={};
var errorTable={};
function getkey(method,path){
  return method.toUpperCase()+" "+path;
}
function app(method,path,app){
  var httpMethod=method || "GET";
  var mypath=path || '/';
  appTable[getkey(httpMethod,mypath)]=app;
}
function get(path,app){
  appTable[getkey("GET",path)]=app;
}
function put(path,app){
  appTable[getkey("PUT",path)]=app;
}
function del(path,app){
  appTable[getkey("DELETE",path)]=app;
}
function post(path,app){
  appTable[getkey("POST",path)]=app;
}
function error(errorCode,errorMessage){
  errorTable[errorCode]=errorMessage;
}
function run(request, response){
  var myUrl=url.parse(request.url);
  var pathName=myUrl.pathname;
  var accessKey=getkey(request.method,pathName);
  var app=appTable[accessKey];
  if(app){
    console.log("access %s",accessKey);
      app(request, response);
  }else{
    var msg=errorTable[404] || "404 error message not defined";
    console.log("access %s NOT FOUND",pathName);
    response.writeHead(404,msg);
    response.end(`${msg}:Path Not Found ${pathName}\n`);
  }
}
exports.run=run;
exports.app=app;
exports.get=get;
exports.put=put;
exports.post=post;
exports.del=del;
exports.error=error;
