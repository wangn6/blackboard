var url = require('url');
function cookies(headers){
  return (headers && headers.cookie)?' '+headers.cookie:'';
}
function getkey(method,path,headers){
    return method.toUpperCase()+" "+path+cookies(headers);
  }
function apps(){
  this.appTable={};
  this.errorTable={};
}
apps.prototype.toString=function(){
  return JSON.stringify(Object.keys(this.appTable));
}
apps.prototype.app=function(method,path,func,headers){
    var httpMethod=method || "GET";
    var mypath=path || '/';
    var key=getkey(httpMethod,mypath,headers);
//    console.log("Apps set key=%s",key);
    this.appTable[key]=func;
  }
apps.prototype.get=function(path,app){
    this.appTable[getkey("GET",path)]=app;
  }
apps.prototype.put=function(path,app){
    this.appTable[getkey("PUT",path)]=app;
  }
apps.prototype.post=function(path,app){
    this.appTable[getkey("POST",path)]=app;
  }
apps.prototype.del=function(path,app){
    this.appTable[getkey("DELETE",path)]=app;
  }
apps.prototype.error=function(errorCode,errorMessage){
    this.errorTable[errorCode]=errorMessage;
  }
  apps.prototype.run=function(request, response){
      var self=this;
      var myUrl=url.parse(request.url);
      var pathName=myUrl.pathname;
      var accessKey=getkey(request.method,pathName,request.headers);
      var app=self.appTable[accessKey];
  //    console.log("Apps accesskey=%s",accessKey);
      if(app){
        app(request, response);
        return true
      }
      return false;
  }
module.exports=apps;
