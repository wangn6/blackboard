const http = require('http');
const net= require('net');
const https = require('https');
const fs = require('fs');

function startHttps(route,httpsPort,options){
  https.createServer(options, (req, res) => {
    console.log("ProxyServer receive HTTPS req:%s",req.url )
    route.run(req, res);
  }).listen(httpsPort);
  console.log("Proxy Server HTTPS listening on %d",httpsPort)
}
function onConnect(proxy,httpsPort){
  proxy.on('connect', (req, cltSocket, head) => {
      var hostname="localhost";
      const srvSocket = net.connect(httpsPort,hostname, () => {
          cltSocket.write('HTTP/1.1 200 Connection Established\r\n' +
                          'Proxy-agent: Node.js-Proxy\r\n' +
                          '\r\n');
          srvSocket.write(head);
          srvSocket.pipe(cltSocket);
          cltSocket.pipe(srvSocket);
        });

    });
}

exports.start=function(route,port,httpsPort,httpsOptions){
  var proxyPort=port || 8080;
  var proxyServer=http.createServer(function(request, response) {
    route.run(request, response);
  }).listen(proxyPort);
  console.log("Proxy Server started listening on %d",proxyPort);
  if(httpsPort){
    startHttps(route,httpsPort,httpsOptions);
    onConnect(proxyServer,httpsPort);
  }

}
