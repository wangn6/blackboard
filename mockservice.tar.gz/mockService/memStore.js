var fs=require('fs');
function cookies(request){
  var cookies=request.headers.cookie;
  console.log("cookie:%s",cookies);
  return typeof cookies!='undefined'?' '+cookies:'';
}
function getKey(request){
//  console.log("memStore get request:%s",JSON.stringify(request))
  var path=request.path;
  var method=request.method;
  return request.hostname+":"+request.port+" "+method+" "+path+cookies(request);
}
var memMap={};
function storeData(key,value){
  memMap[key]=value;
}
function getData(key,value){
  return memMap[key];
}

exports.put=function(request,response){
    var key=getKey(request)
    storeData(key,{req:request,res:response});
    console.log("memStore cache request key=%s response body=",key,JSON.stringify(response.body))
}
exports.get=function(request){
    var key=getKey(request);
    var cache=getData(key);
    if(cache){
      return {key:key,data:cache.res};
    }
    return null;
}
exports.getAll=function(){
    return memMap;
}
exports.log=function(onComplete){
  fs.writeFile('cache.json',JSON.stringify(memMap),(err) => {
         onComplete(err || "Cache has been saved to file!")
  });
}
exports.load=function(onComplete){
  fs.readFile('cache.json',(err,data) => {
         if(err){
           console.error("Read cache file error: %s",err);
         }else{
           memMap=JSON.parse(data);
           console.log("Read cache file successful!");
         }
         if(onComplete)
            onComplete(err);
  });
}

// function test(){
//   var req={path:"/test",method:"POST"};
//   var res={status:200,body:"test response body"}
//   exports.put(req,res);
//   console.log("Test MemStore:",JSON.stringify(exports.getAll()));
// }
// test()
