var adminServer=require("./adminServer.js");
var proxyServer=require("./proxyServer.js");
adminServer.start(8081);
proxyServer.start();
